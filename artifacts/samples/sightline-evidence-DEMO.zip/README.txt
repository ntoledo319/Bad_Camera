*** DEMONSTRATION — NOT A REAL SIGHTING ***
This package was generated from bundled demonstration data. It does not describe a real sighting.

SIGHTLINE EVIDENCE PACKAGE
==========================

Record: demo-observation-1 (revision 2)
Disclosure profile: public-default

What this package is
--------------------
A machine-readable export of one notebook record from the Sightline app, containing only the
fields the exporter selected. Media files are re-rendered derivatives with metadata removed
unless the profile is "private-full-evidence".

How to check it
---------------
Recompute SHA-256 for each file and compare with checksums.sha256, or run the bundled
verifier from the Sightline source archive:

    npx tsx tools/verify-evidence/verify.ts <package.zip>

A matching result means: "File checksums match this manifest." It does NOT mean the event
is proven authentic. The package is not signed; anyone could alter it and recompute hashes.

Limitations
-----------
- Mapping/source claims can be wrong or stale.
- Phone time, GPS and imported metadata are not independently attested.
- A checksum detects a change relative to a known digest; it does not prove the scene, time, location or claim is true.
- These materials do not establish that a camera recorded any person or vehicle.
- Legal admissibility depends on context; the app does not certify it.

A location report is not proof of recording.
